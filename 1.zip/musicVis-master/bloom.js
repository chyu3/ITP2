function Bloom(){
    this.name = "Bloom";
    var music;
    var density = 300;
    //circle size adjustment 
    var tunnelRadius = 500;
    var angleStep;
    var angles = [];
    
    
    this.setup = function(){
        angleMode(DEGREES);
        //
        angleStep = 360 / density;
        
        //initial random angle
        for(let i = 0; i< density;i++){
            angles.push(random(360));
        }
        
    }
    this.setup();
    
    this.mousePressed = function(){
        music.loop();
    }
    
    //draw light spectrum shape
    this.draw = function(){
        background(120, 60, 100);
        //get frequency data
        let spectrum = fourier.analyze();
        
        //average amplitude of low frequencies(bass)
        let bassAmp = 0;
        for(let i=1; i<50;i++){
            bassAmp += spectrum[i];
        }
        bassAmp /= 50;
        
        // Adjust tunnel radius based on the bass amplitude
        let newRadius = map(bassAmp, 0, 255, 50, 400); 
        // Adjust range using lerp
        tunnelRadius = lerp(tunnelRadius, newRadius, 0.1);

        // Update tunnel angles
        for (let i = 0; i < density; i++) {
            angles[i] += map(bassAmp, 0, 255, 0.5, 2);
        }
        
        // Draw tunnel effect
        translate(width / 2, height / 2);
    //    let r = random(255);
    //    let g = random(255);
    //    let b = random(255);
    //    stroke(r, g, b);
        stroke(255);

        noFill();
        
        for (let i = 0; i < density; i++) {
            let x1 = cos(angles[i]) * tunnelRadius * (i / density);
            let y1 = sin(angles[i]) * tunnelRadius * (i / density);
            let x2 = cos(angles[i]) * tunnelRadius * ((i + 1) / density);
            let y2 = sin(angles[i]) * tunnelRadius * ((i + 1) / density);
            line(x1, y1, x2, y2);
        }

        // Loop tunnel angles
        if (frameCount % 120 === 0) {
            angles.shift();
            angles.push(random(360));
        }
        
    }
    
}